<?php
/**
 * FILE: proses_edit.php
 * FUNGSI: Mengolah pembaruan data & foto di database
 */
require "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_produk   = intval($_POST['id_produk']);
    $nama_produk = mysqli_real_escape_string($koneksi, $_POST['nama_produk']);
    $id_kategori  = intval($_POST['id_kategori']);
    $harga       = intval($_POST['harga']);
    $stok        = intval($_POST['stok']);
    $foto_lama   = $_POST['foto_lama'];

    // Cek jika pengguna memilih file foto baru
    if ($_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $foto_nama = $_FILES['foto']['name'];
        $foto_tmp  = $_FILES['foto']['tmp_name'];
        $foto_ext  = strtolower(pathinfo($foto_nama, PATHINFO_EXTENSION));

        $nama_foto_baru = time() . '_' . rand(100, 999) . '.' . $foto_ext;
        $folder_tujuan  = "uploads/" . $nama_foto_baru;

        if (move_uploaded_file($foto_tmp, $folder_tujuan)) {
            // Hapus foto lama jika file-nya ada di folder uploads/
            if (file_exists("uploads/" . $foto_lama) && $foto_lama != 'default.jpg') {
                unlink("uploads/" . $foto_lama);
            }
            $foto_final = $nama_foto_baru;
        } else {
            $foto_final = $foto_lama;
        }
    } else {
        // Jika tidak upload foto baru, gunakan foto lama
        $foto_final = $foto_lama;
    }

    // Query Update Data
    $query = "UPDATE produk SET 
                id_kategori = $id_kategori,
                nama_produk = '$nama_produk',
                harga = $harga,
                stok = $stok,
                foto = '$foto_final'
              WHERE id_produk = $id_produk";

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php");
        exit();
    } else {
        echo "Gagal memperbarui data: " . mysqli_error($koneksi);
    }
}
?>