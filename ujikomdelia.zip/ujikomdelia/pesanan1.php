<?php
/**
 * FILE: pesanan.php
 * FUNGSI: Mengelola Data Pesanan Masuk (Ubah Status & Hapus Pesanan)
 */
session_start();
require "koneksi.php";

// Cek status login admin
$is_admin = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;

$pesan_sukses = "";
$pesan_error = "";

// --- PROSES UBAH STATUS PESANAN ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $id_pesanan = intval($_POST['id_pesanan']);
    $status_baru = mysqli_real_escape_string($koneksi, $_POST['status']);

    $q_update = "UPDATE pesanan SET status = '$status_baru' WHERE id_pesanan = $id_pesanan";
    if (mysqli_query($koneksi, $q_update)) {
        $pesan_sukses = "Status pesanan #$id_pesanan berhasil diperbarui menjadi '$status_baru'!";
    } else {
        $pesan_error = "Gagal memperbarui status: " . mysqli_error($koneksi);
    }
}

// --- PROSES HAPUS PESANAN ---
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id_pesanan = intval($_GET['id']);
    
    $q_hapus = "DELETE FROM pesanan WHERE id_pesanan = $id_pesanan";
    if (mysqli_query($koneksi, $q_hapus)) {
        $pesan_sukses = "Pesanan #$id_pesanan berhasil dihapus!";
    } else {
        $pesan_error = "Gagal menghapus pesanan: " . mysqli_error($koneksi);
    }
}

// Ambil seluruh data pesanan
$query_pesanan = "SELECT * FROM pesanan ORDER BY id_pesanan DESC";
$result_pesanan = mysqli_query($koneksi, $query_pesanan);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pesanan - TokoKita</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
        body { background-color: #f8fafc; color: #0f172a; padding-bottom: 3rem; }

        /* NAVBAR */
        .navbar { background: #fff; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; position: sticky; top: 0; z-index: 100; }
        .logo { font-size: 1.4rem; font-weight: 700; color: #4f46e5; text-decoration: none; display: flex; align-items: center; gap: 8px; }
        .nav-links { display: flex; align-items: center; gap: 12px; }
        .btn-nav { text-decoration: none; padding: 8px 16px; border-radius: 8px; font-size: 0.85rem; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; }
        .btn-kembali { background: #f1f5f9; color: #475569; }
        .btn-kembali:hover { background: #e2e8f0; }

        /* KONTEN UTAMA */
        .container { max-width: 1100px; margin: 2rem auto; padding: 0 1rem; }
        .header-section { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
        .header-section h2 { font-size: 1.5rem; color: #0f172a; display: flex; align-items: center; gap: 10px; }

        /* ALERT NOTIFIKASI */
        .alert { padding: 0.85rem 1rem; border-radius: 8px; margin-bottom: 1.5rem; font-size: 0.9rem; font-weight: 500; display: flex; align-items: center; gap: 8px; }
        .alert-success { background: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }

        /* TABEL PESANAN */
        .table-card { background: #fff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem; }
        th { background: #f8fafc; padding: 14px 16px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0; }
        td { padding: 14px 16px; border-bottom: 1px solid #e2e8f0; vertical-align: middle; }
        tr:last-child td { border-bottom: none; }

        /* BADGE STATUS */
        .badge { display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; }
        .badge-Pending { background: #fef3c7; color: #b45309; }
        .badge-Diproses { background: #dbeafe; color: #1d4ed8; }
        .badge-Selesai { background: #d1fae5; color: #047857; }
        .badge-Dibatalkan { background: #fee2e2; color: #b91c1c; }

        /* FORM CHANGE STATUS */
        .form-status { display: flex; align-items: center; gap: 6px; margin-top: 6px; }
        .select-status { padding: 4px 8px; border-radius: 6px; border: 1px solid #cbd5e1; font-size: 0.8rem; background: #fff; color: #334155; }
        .btn-update { background: #4f46e5; color: #fff; border: none; padding: 5px 10px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; cursor: pointer; }
        .btn-update:hover { background: #4338ca; }

        /* AKSI HAPUS */
        .btn-delete { color: #ef4444; text-decoration: none; font-weight: 600; font-size: 0.85rem; display: inline-flex; align-items: center; gap: 4px; }
        .btn-delete:hover { color: #dc2626; }
    </style>
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar">
        <a href="index.php" class="logo"><i class="fa-solid fa-shop"></i> TokoKita</a>
        <div class="nav-links">
            <a href="index.php" class="btn-nav btn-kembali"><i class="fa-solid fa-arrow-left"></i> Kembali ke Dashboard</a>
        </div>
    </nav>

    <div class="container">
        <div class="header-section">
            <h2><i class="fa-solid fa-boxes-packing" style="color: #4f46e5;"></i> Kelola Data Pesanan</h2>
        </div>

        <!-- NOTIFIKASI -->
        <?php if (!empty($pesan_sukses)) : ?>
            <div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> <?= $pesan_sukses; ?></div>
        <?php endif; ?>

        <?php if (!empty($pesan_error)) : ?>
            <div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?= $pesan_error; ?></div>
        <?php endif; ?>

        <!-- TABEL DATA PESANAN -->
        <div class="table-card">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Pembeli</th>
                        <th>Alamat & Kontak</th>
                        <th>Total Harga</th>
                        <th>Status Saat Ini</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result_pesanan && mysqli_num_rows($result_pesanan) > 0) : ?>
                        <?php while ($ps = mysqli_fetch_assoc($result_pesanan)) : ?>
                            <tr>
                                <td><b>#<?= $ps['id_pesanan']; ?></b></td>
                                <td>
                                    <strong><?= htmlspecialchars($ps['nama_pembeli']); ?></strong>
                                </td>
                                <td>
                                    <small style="color: #64748b;"><i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($ps['alamat']); ?></small><br>
                                    <small style="color: #64748b;"><i class="fa-solid fa-phone"></i> <?= htmlspecialchars($ps['no_hp'] ?? '-'); ?></small>
                                </td>
                                <td><b style="color: #059669;">Rp <?= number_format($ps['total_harga'], 0, ',', '.'); ?></b></td>
                                <td>
                                    <!-- Badge Status -->
                                    <span class="badge badge-<?= $ps['status']; ?>"><?= $ps['status']; ?></span>

                                    <!-- Form Ubah Status -->
                                    <form action="" method="POST" class="form-status">
                                        <input type="hidden" name="id_pesanan" value="<?= $ps['id_pesanan']; ?>">
                                        <select name="status" class="select-status">
                                            <option value="Pending" <?= $ps['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="Diproses" <?= $ps['status'] == 'Diproses' ? 'selected' : ''; ?>>Diproses</option>
                                            <option value="Selesai" <?= $ps['status'] == 'Selesai' ? 'selected' : ''; ?>>Selesai</option>
                                            <option value="Dibatalkan" <?= $ps['status'] == 'Dibatalkan' ? 'selected' : ''; ?>>Dibatalkan</option>
                                        </select>
                                        <button type="submit" name="update_status" class="btn-update">Ubah</button>
                                    </form>
                                </td>
                                <td>
                                    <a href="pesanan.php?action=delete&id=<?= $ps['id_pesanan']; ?>" 
                                       onclick="return confirm('Apakah Anda yakin ingin menghapus pesanan #<?= $ps['id_pesanan']; ?>?');" 
                                       class="btn-delete">
                                        <i class="fa-solid fa-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: #64748b; padding: 2.5rem;">
                                Belum ada pesanan masuk.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>