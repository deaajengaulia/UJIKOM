<?php
/**
 * FILE: index.php
 * DATABASE: marketplace
 * Tampilan: Modern Soft-UI Kapsul & Glassmorphism
 */

require "koneksi.php";

$query = "SELECT produk.*, kategori.nama_kategori
          FROM produk
          JOIN kategori ON produk.id_kategori = kategori.id_kategori
          ORDER BY produk.created_at DESC";

$hasil = mysqli_query($koneksi, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Storefront - Marketplace</title>
    <!-- Google Fonts untuk Tipografi Modern -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-color: #f8fafc;
            --card-bg: #ffffff;
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --accent-green: #10b981;
            --accent-warning: #f59e0b;
            --accent-danger: #ef4444;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            padding-bottom: 50px;
        }

        /* Top Header Navigation */
        .app-header {
            background: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            padding: 1rem 2rem;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .brand-logo {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Main Container */
        .main-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1.5rem;
        }

        .banner-section {
            background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
            border-radius: 16px;
            padding: 2rem;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2.5rem;
            box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.25);
        }

        .banner-text h2 {
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .banner-text p {
            opacity: 0.9;
            font-size: 0.95rem;
        }

        /* Buttons */
        .btn-add {
            background-color: #ffffff;
            color: var(--primary);
            padding: 0.75rem 1.25rem;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.2s ease;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
        }

        .btn-add:hover {
            background-color: #f1f5f9;
            transform: translateY(-2px);
        }

        /* Product Grid */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 1.5rem;
        }

        /* Card Component */
        .product-card {
            background: var(--card-bg);
            border-radius: 16px;
            border: 1px solid #e2e8f0;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .product-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 12px 20px -5px rgba(0, 0, 0, 0.08);
            border-color: #cbd5e1;
        }

        .image-wrapper {
            position: relative;
            width: 100%;
            height: 190px;
            background-color: #f1f5f9;
            overflow: hidden;
        }

        .image-wrapper img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .product-card:hover .image-wrapper img {
            transform: scale(1.05);
        }

        .category-badge {
            position: absolute;
            top: 12px;
            left: 12px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(4px);
            color: var(--text-main);
            font-size: 0.7rem;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 20px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .card-details {
            padding: 1.25rem;
            display: flex;
            flex-direction: column;
            flex-grow: 1;
        }

        .product-title {
            font-size: 1rem;
            font-weight: 600;
            color: var(--text-main);
            margin-bottom: 0.75rem;
            line-height: 1.4;
        }

        .meta-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: auto;
            padding-bottom: 1rem;
            border-bottom: 1px dashed #e2e8f0;
        }

        .price {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--primary);
        }

        .stock-pill {
            font-size: 0.75rem;
            color: var(--text-muted);
            background: #f1f5f9;
            padding: 2px 8px;
            border-radius: 6px;
        }

        /* Action Buttons Inside Card */
        .card-actions {
            display: flex;
            gap: 8px;
            margin-top: 1rem;
        }

        .btn-action {
            flex: 1;
            text-align: center;
            padding: 0.5rem;
            font-size: 0.8rem;
            font-weight: 600;
            border-radius: 8px;
            text-decoration: none;
            transition: background 0.2s ease;
        }

        .btn-edit-alt {
            background-color: #fef3c7;
            color: #92400e;
        }
        .btn-edit-alt:hover {
            background-color: #fde68a;
        }

        .btn-delete-alt {
            background-color: #fee2e2;
            color: #991b1b;
        }
        .btn-delete-alt:hover {
            background-color: #fecaca;
        }
    </style>
</head>
<body>

    <!-- Header Navigation -->
    <header class="app-header">
        <div class="header-wrapper">
            <div class="brand-logo">
                <span>🛍️</span> Marketplace DELIA
            </div>
        </div>
    </header>

    <main class="main-container">
        
        <!-- Banner Top Component -->
        <div class="banner-section">
            <div class="banner-text">
                <h2>Kelola Katalog Produk</h2>
                <p></p>
            </div>
            <a href="tambah.php" class="btn-add">+ Produk Baru</a>
        </div>

        <!-- Grid Products -->
        <div class="product-grid">
            <?php if (mysqli_num_rows($hasil) > 0) : ?>
                <?php while ($produk = mysqli_fetch_assoc($hasil)) : ?>
                    <div class="product-card">
                        
                        <!-- Gambar & Badge Kategori -->
                        <div class="image-wrapper">
                            <span class="category-badge">
                                <?php echo htmlspecialchars($produk['nama_kategori']); ?>
                            </span>
                            <img src="uploads/<?php echo htmlspecialchars($produk['foto']); ?>" 
                                 alt="<?php echo htmlspecialchars($produk['nama_produk']); ?>"
                                 onerror="this.src='https://via.placeholder.com/300x200?text=No+Image'">
                        </div>

                        <!-- Card Content -->
                        <div class="card-details">
                            <h3 class="product-title"><?php echo htmlspecialchars($produk['nama_produk']); ?></h3>
                            
                            <div class="meta-info">
                                <span class="price">Rp <?php echo number_format($produk['harga'], 0, ',', '.'); ?></span>
                                <span class="stock-pill">Stok: <?php echo $produk['stok']; ?></span>
                            </div>

                            <!-- Tombol Aksi -->
                            <div class="card-actions">
                                <a href="edit.php?id=<?php echo $produk['id_produk']; ?>" class="btn-action btn-edit-alt">
                                    Edit
                                </a>
                                <a href="delete.php?id=<?php echo $produk['id_produk']; ?>" 
                                   class="btn-action btn-delete-alt"
                                   onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">
                                    Hapus
                                </a>
                            </div>
                        </div>

                    </div>
                <?php endwhile; ?>
            <?php else : ?>
                <div style="grid-column: 1 / -1; text-align: center; color: var(--text-muted); padding: 3rem 0;">
                    <p>Belum ada produk yang tersedia.</p>
                </div>
            <?php endif; ?>
        </div>

    </main>

</body>
</html>