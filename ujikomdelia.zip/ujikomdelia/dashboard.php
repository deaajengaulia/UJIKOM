<?php
/**
 * FILE: index.php / dashboard.php
 * FUNGSI: Halaman Utama dengan Sidebar Menu (Dashboard, Produk, Kategori, Pesanan)
 */
session_start();
require "koneksi.php";

// =========================================================================
// PROTEKSI HALAMAN: Cek apakah session admin sudah login
// Jika belum login, tendang (redirect) ke halaman login.php
// =========================================================================
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    $_SESSION['error'] = 'Anda harus login terlebih dahulu untuk mengakses halaman ini!';
    header('Location: login.php');
    exit(); // Hentikan eksekusi script selanjutnya
}

$is_admin = true; // Karena sudah lolos proteksi di atas

// Menentukan menu aktif dari URL parameter ?page=... (Default: dashboard)
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

// Mengambil Ringkasan Data untuk Dashboard
$total_produk   = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM produk"))['total'] ?? 0;
$total_kategori = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM kategori"))['total'] ?? 0;
$total_pesanan  = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM pesanan"))['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Toko - TokoKita</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
        body { background-color: #f8fafc; color: #0f172a; display: flex; min-height: 100vh; }

        /* SIDEBAR MENU */
        .sidebar { width: 250px; background: #0f172a; color: #fff; padding: 1.5rem 1rem; display: flex; flex-direction: column; shrink: 0; }
        .sidebar h2 { font-size: 1.3rem; color: #6366f1; margin-bottom: 2rem; padding: 0 0.5rem; display: flex; align-items: center; gap: 10px; }
        .nav-menu { list-style: none; display: flex; flex-direction: column; gap: 8px; flex-grow: 1; }
        .nav-menu a { display: flex; align-items: center; gap: 12px; padding: 0.8rem 1rem; color: #94a3b8; text-decoration: none; border-radius: 8px; font-size: 0.9rem; font-weight: 500; transition: all 0.2s; }
        .nav-menu a:hover, .nav-menu a.active { background: #1e293b; color: #6366f1; font-weight: 600; }
        
        .auth-btn { margin-top: auto; padding-top: 1rem; border-top: 1px solid #1e293b; }
        .btn-logout-side { background: #450a0a; color: #fca5a5 !important; justify-content: center; }

        /* KONTEN UTAMA */
        .main-content { flex: 1; padding: 2rem; overflow-y: auto; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; }
        .header h1 { font-size: 1.6rem; color: #1e293b; text-transform: capitalize; }

        /* CARD STATISTIK DASHBOARD */
        .grid-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
        .card-stat { background: #fff; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0; display: flex; align-items: center; gap: 1.5rem; }
        .card-stat .icon { width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; }
        .stat-blue { background: #e0e7ff; color: #4f46e5; }
        .stat-green { background: #d1fae5; color: #059669; }
        .stat-orange { background: #fef3c7; color: #d97706; }
        .card-stat h3 { font-size: 1.4rem; color: #0f172a; }
        .card-stat p { font-size: 0.85rem; color: #64748b; }

        /* TABEL & DESAIN UMUM */
        .table-card { background: #fff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; }
        .table-header { padding: 1rem 1.5rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem; }
        th { background: #f8fafc; padding: 12px 16px; font-weight: 600; color: #475569; }
        td { padding: 14px 16px; border-bottom: 1px solid #e2e8f0; vertical-align: middle; }
        
        .btn-add { background: #4f46e5; color: white; padding: 0.6rem 1rem; border-radius: 8px; text-decoration: none; font-size: 0.85rem; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; }
        .btn-add:hover { background: #4338ca; }
        .img-thumb { width: 45px; height: 45px; object-fit: cover; border-radius: 6px; }
        .btn-delete { color: #ef4444; text-decoration: none; font-weight: 600; font-size: 0.85rem; }
        .badge { padding: 4px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; }
        .badge-Pending { background: #fef3c7; color: #d97706; }
        .badge-Diproses { background: #dbeafe; color: #2563eb; }
        .badge-Selesai { background: #d1fae5; color: #059669; }
    </style>
</head>
<body>

    <!-- SIDEBAR NAVIGASI MENU -->
    <div class="sidebar">
        <h2><i class="fa-solid fa-shop"></i> TokoKita</h2>
        <ul class="nav-menu">
            <li><a href="index.php?page=dashboard" class="<?= $page == 'dashboard' ? 'active' : ''; ?>"><i class="fa-solid fa-chart-pie"></i> Dashboard</a></li>
            <li><a href="index.php?page=produk" class="<?= $page == 'produk' ? 'active' : ''; ?>"><i class="fa-solid fa-box"></i> Produk</a></li>
            <li><a href="index.php?page=kategori" class="<?= $page == 'kategori' ? 'active' : ''; ?>"><i class="fa-solid fa-layer-group"></i> Kategori</a></li>
            <li><a href="index.php?page=pesanan" class="<?= $page == 'pesanan' ? 'active' : ''; ?>"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a></li>
        </ul>

        <div class="auth-btn">
            <a href="logout.php" class="btn-logout-side"><i class="fa-solid fa-right-from-bracket"></i> Logout Admin</a>
        </div>
    </div>

    <!-- AREA KONTEN BERDASARKAN MENU -->
    <div class="main-content">
        <div class="header">
            <h1>Menu <?= ucfirst($page); ?></h1>
        </div>

        <?php if ($page == 'dashboard') : ?>
            <!-- 1. MENU DASHBOARD -->
            <div class="grid-cards">
                <div class="card-stat">
                    <div class="icon stat-blue"><i class="fa-solid fa-box"></i></div>
                    <div>
                        <h3><?= $total_produk; ?></h3>
                        <p>Total Produk</p>
                    </div>
                </div>
                <div class="card-stat">
                    <div class="icon stat-green"><i class="fa-solid fa-layer-group"></i></div>
                    <div>
                        <h3><?= $total_kategori; ?></h3>
                        <p>Total Kategori</p>
                    </div>
                </div>
                <div class="card-stat">
                    <div class="icon stat-orange"><i class="fa-solid fa-cart-shopping"></i></div>
                    <div>
                        <h3><?= $total_pesanan; ?></h3>
                        <p>Total Pesanan</p>
                    </div>
                </div>
            </div>

            <div class="table-card">
                <div class="table-header">
                    <h3>Produk Terbaru</h3>
                    <a href="tambah.php" class="btn-add"><i class="fa-solid fa-plus"></i> Tambah Produk</a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Gambar</th>
                            <th>Nama Produk</th>
                            <th>Harga</th>
                            <th>Stok</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $q_recent = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY id_produk DESC LIMIT 5");
                        if ($q_recent && mysqli_num_rows($q_recent) > 0) :
                            while ($p = mysqli_fetch_assoc($q_recent)) :
                        ?>
                        <tr>
                            <td><img src="uploads/<?= $p['foto']; ?>" class="img-thumb" alt=""></td>
                            <td><b><?= htmlspecialchars($p['nama_produk']); ?></b></td>
                            <td>Rp <?= number_format($p['harga'], 0, ',', '.'); ?></td>
                            <td><?= $p['stok']; ?> unit</td>
                        </tr>
                        <?php 
                            endwhile;
                        else :
                        ?>
                        <tr><td colspan="4" style="text-align:center;">Belum ada data produk. Silakan tambahkan lewat <b>tambah.php</b></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif ($page == 'produk') : ?>
            <!-- 2. MENU PRODUK -->
            <div class="table-card">
                <div class="table-header">
                    <h3>Daftar Produk</h3>
                    <a href="tambah.php" class="btn-add"><i class="fa-solid fa-plus"></i> Tambah Produk Baru</a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Gambar</th>
                            <th>Nama Produk</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $q_prod = mysqli_query($koneksi, "SELECT produk.*, kategori.nama_kategori FROM produk LEFT JOIN kategori ON produk.id_kategori = kategori.id_kategori ORDER BY id_produk DESC");
                        if ($q_prod && mysqli_num_rows($q_prod) > 0) :
                            while ($p = mysqli_fetch_assoc($q_prod)) :
                        ?>
                        <tr>
                            <td><img src="uploads/<?= $p['foto']; ?>" class="img-thumb" alt=""></td>
                            <td><b><?= htmlspecialchars($p['nama_produk']); ?></b></td>
                            <td><?= $p['nama_kategori'] ?? '-'; ?></td>
                            <td>Rp <?= number_format($p['harga'], 0, ',', '.'); ?></td>
                            <td><?= $p['stok']; ?></td>
                            <td>
                                <a href="proses_hapus.php?id=<?= $p['id_produk']; ?>" onclick="return confirm('Hapus produk ini?');" class="btn-delete"><i class="fa-solid fa-trash"></i> Hapus</a>
                            </td>
                        </tr>
                        <?php 
                            endwhile;
                        else :
                        ?>
                        <tr><td colspan="6" style="text-align:center;">Belum ada data produk. Tambahkan dari menu <b>tambah.php</b></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif ($page == 'kategori') : ?>
            <!-- 3. MENU KATEGORI -->
            <div class="table-card">
                <div class="table-header">
                    <h3>Daftar Kategori</h3>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID Kategori</th>
                            <th>Nama Kategori</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $q_kat = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY id_kategori ASC");
                        if ($q_kat && mysqli_num_rows($q_kat) > 0) :
                            while ($k = mysqli_fetch_assoc($q_kat)) :
                        ?>
                        <tr>
                            <td>#<?= $k['id_kategori']; ?></td>
                            <td><b><?= htmlspecialchars($k['nama_kategori']); ?></b></td>
                        </tr>
                        <?php 
                            endwhile;
                        else :
                        ?>
                        <tr><td colspan="2" style="text-align:center;">Belum ada data kategori.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <?php elseif ($page == 'pesanan') : ?>
            <!-- 4. MENU PESANAN -->
            <div class="table-card">
                <div class="table-header">
                    <h3>Data Pesanan Masuk</h3>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID Pesanan</th>
                            <th>Nama Pembeli</th>
                            <th>Alamat</th>
                            <th>Total Harga</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $q_pesan = mysqli_query($koneksi, "SELECT * FROM pesanan ORDER BY id_pesanan DESC");
                        if ($q_pesan && mysqli_num_rows($q_pesan) > 0) :
                            while ($ps = mysqli_fetch_assoc($q_pesan)) :
                        ?>
                        <tr>
                            <td><b>#<?= $ps['id_pesanan']; ?></b></td>
                            <td>
                                <b><?= htmlspecialchars($ps['nama_pembeli']); ?></b><br>
                                <small><?= $ps['no_hp'] ?? ''; ?></small>
                            </td>
                            <td><?= htmlspecialchars($ps['alamat']); ?></td>
                            <td><b>Rp <?= number_format($ps['total_harga'], 0, ',', '.'); ?></b></td>
                            <td><span class="badge badge-<?= $ps['status']; ?>"><?= $ps['status']; ?></span></td>
                            <td>
                                <a href="hapus_pesanan.php?id=<?= $ps['id_pesanan']; ?>" onclick="return confirm('Hapus pesanan ini?');" class="btn-delete"><i class="fa-solid fa-trash"></i> Hapus Pesanan</a>
                            </td>
                        </tr>
                        <?php 
                            endwhile;
                        else :
                        ?>
                        <tr><td colspan="6" style="text-align:center;">Belum ada transaksi/pesanan masuk.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

    </div>

</body>
</html>