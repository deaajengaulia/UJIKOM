<?php
/**
 * FILE: hapus_pesanan.php
 * FUNGSI: Menghapus data transaksi pesanan pembeli dari database
 */
session_start();

// Proteksi Halaman: Hanya Admin yang bisa menghapus pesanan
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

require "koneksi.php";

// Cek apakah ada ID pesanan yang dikirim via URL
if (isset($_GET['id'])) {
    $id_pesanan = mysqli_real_escape_string($koneksi, $_GET['id']);

    // 1. Hapus rincian barang dari tabel detail_pesanan terlebih dahulu
    $query_detail = "DELETE FROM detail_pesanan WHERE id_pesanan = '$id_pesanan'";
    mysqli_query($koneksi, $query_detail);

    // 2. Hapus data utama pesanan dari tabel pesanan
    $query_pesanan = "DELETE FROM pesanan WHERE id_pesanan = '$id_pesanan'";

    if (mysqli_query($koneksi, $query_pesanan)) {
        echo "<script>
            alert('Data pesanan berhasil dihapus!');
            window.location.href = 'pesanan.php';
        </script>";
    } else {
        echo "<script>
            alert('Gagal menghapus data pesanan!');
            window.location.href = 'pesanan.php';
        </script>";
    }
} else {
    header("Location: pesanan.php");
    exit;
}
?>