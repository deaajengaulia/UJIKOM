<?php
session_start();

// Jika admin sudah login, langsung alihkan ke dashboard
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: index.php');
    exit();
}

// Proses autentikasi saat form dikirim (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Hubungkan ke file koneksi.php di folder utama
    require_once __DIR__ . '/koneksi.php';
    
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    // Validasi input kosong
    if (empty($username) || empty($password)) {
        $_SESSION['error'] = 'Username dan password harus diisi!';
        header('Location: login.php');
        exit();
    }
    
    // Query mengecek kolom 'username' (bukan email)
    $stmt = mysqli_prepare($koneksi, "SELECT * FROM admin WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $admin = mysqli_fetch_assoc($result);
    
    // Validasi password (mendukung teks biasa maupun hash)
    if ($admin && ($password === $admin['password'] || password_verify($password, $admin['password']))) {
        session_regenerate_id(true); // Pengamanan dari Session Fixation

        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id']   = $admin['id_admin'] ?? $admin['id'] ?? 1;
        $_SESSION['admin_name'] = $admin['nama'] ?? $admin['username'];
        $_SESSION['success']    = 'Selamat datang, ' . htmlspecialchars($_SESSION['admin_name']) . '!';
        
        header('Location: dashboard.php');
        exit();
    } else {
        $_SESSION['error'] = 'Username atau password salah!';
        header('Location: login.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Administrator Marketplace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .login-card {
            max-width: 420px;
            margin: auto;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            background: white;
            border: none;
        }
        .login-card .card-body {
            padding: 40px;
        }
        .login-card .card-title {
            text-align: center;
            margin-bottom: 5px;
            font-size: 1.5rem;
            color: #2d3748;
        }
        .login-card .card-subtitle {
            text-align: center;
            color: #718096;
            margin-bottom: 25px;
            font-size: 0.95rem;
        }
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px;
            transition: all 0.3s;
            border-radius: 10px;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
            color: white;
        }
        .form-control {
            border-radius: 10px;
            padding: 12px 15px;
            border: 2px solid #e2e8f0;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.15);
        }
        .brand-icon {
            text-align: center;
            font-size: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }
        .password-wrapper {
            position: relative;
        }
        .password-wrapper .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #a0aec0;
            transition: color 0.3s;
        }
        .password-wrapper .toggle-password:hover {
            color: #667eea;
        }
        .form-label {
            font-weight: 600;
            color: #2d3748;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="card login-card">
        <div class="card-body">
            <div class="brand-icon">
                <i class="fas fa-store-alt"></i>
            </div>
            <h5 class="card-title fw-bold">Login Administrator</h5>
            <p class="card-subtitle">Sistem Manajemen Marketplace</p>

            <!-- Alert Notifikasi Error -->
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i>
                    <?= htmlspecialchars($_SESSION['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <div class="mb-3">
                    <label class="form-label">
                        <i class="fas fa-user me-2"></i>Username
                    </label>
                    <input type="text" class="form-control" name="username" 
                           placeholder="Masukkan username admin" required autofocus>
                </div>
                <div class="mb-3">
                    <label class="form-label">
                        <i class="fas fa-lock me-2"></i>Kata Sandi
                    </label>
                    <div class="password-wrapper">
                        <input type="password" class="form-control" name="password" 
                               id="password" placeholder="Masukkan kata sandi" required>
                        <span class="toggle-password" onclick="togglePasswordVisibility()">
                            <i class="fas fa-eye" id="eyeIcon"></i>
                        </span>
                    </div>
                </div>
                <button type="submit" class="btn btn-login w-100">
                    <i class="fas fa-sign-in-alt me-2"></i> Masuk ke Dashboard
                </button>
                <div class="text-center mt-3">
                    <small class="text-muted">
                        <i class="fas fa-info-circle me-1"></i> 
                        Gunakan akun administrator yang terdaftar
                    </small>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function togglePasswordVisibility() {
    const passwordInput = document.getElementById('password');
    const eyeIcon = document.getElementById('eyeIcon');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.className = 'fas fa-eye-slash';
    } else {
        passwordInput.type = 'password';
        eyeIcon.className = 'fas fa-eye';
    }
}
</script>
</body>
</html>