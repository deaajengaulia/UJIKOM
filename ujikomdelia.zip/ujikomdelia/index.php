<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}
require "koneksi.php";

// 1. Ambil data kategori untuk filter
$query_kategori = "SELECT * FROM kategori ORDER BY nama_kategori ASC";
$hasil_kategori = mysqli_query($koneksi, $query_kategori);

// 2. Ambil data produk dari database (JOIN kategori)
$query_produk = "SELECT produk.*, kategori.nama_kategori 
                 FROM produk 
                 LEFT JOIN kategori ON produk.id_kategori = kategori.id_kategori 
                 ORDER BY produk.id_produk DESC";
$hasil_produk = mysqli_query($koneksi, $query_produk);

// Array untuk menampung ID produk yang valid dari database
$valid_ids = [];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>TokoKita — Marketplace Modern</title>

  <!-- Google Fonts & Font Awesome Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }

    :root {
      --primary: #4f46e5;
      --primary-hover: #4338ca;
      --bg-body: #f8fafc;
      --text-dark: #0f172a;
      --text-muted: #64748b;
      --card-bg: #ffffff;
      --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
      --radius: 16px;
    }

    body {
      background-color: var(--bg-body);
      color: var(--text-dark);
      padding-bottom: 60px;
    }

    /* HEADER / NAVBAR */
    header {
      position: sticky;
      top: 0;
      z-index: 100;
      background: rgba(255, 255, 255, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid #e2e8f0;
    }

    .nav-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 16px 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 16px;
    }

    .logo {
      font-size: 24px;
      font-weight: 700;
      color: var(--primary);
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .search-box {
      flex: 1;
      max-width: 450px;
      position: relative;
    }

    .search-box input {
      width: 100%;
      padding: 10px 16px 10px 42px;
      border-radius: 99px;
      border: 1px solid #cbd5e1;
      outline: none;
      font-size: 14px;
      transition: all 0.3s ease;
    }

    .search-box input:focus {
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
    }

    .search-box i {
      position: absolute;
      left: 16px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--text-muted);
    }

    .nav-actions {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .btn-nav {
      color: white;
      text-decoration: none;
      padding: 10px 16px;
      border-radius: 99px;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 13px;
      transition: opacity 0.2s;
    }

    .btn-add { background: #10b981; }
    .btn-orders { background: #3b82f6; }

    .cart-btn {
      position: relative;
      background: var(--primary);
      color: white;
      border: none;
      padding: 10px 18px;
      border-radius: 99px;
      cursor: pointer;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
    }

    .cart-badge {
      background: #ef4444;
      color: white;
      font-size: 11px;
      border-radius: 50%;
      width: 20px;
      height: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    /* HERO BANNER */
    .hero {
      max-width: 1200px;
      margin: 24px auto;
      padding: 0 24px;
    }

    .hero-banner {
      background: linear-gradient(135deg, #4f46e5 0%, #818cf8 100%);
      border-radius: var(--radius);
      padding: 40px;
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 20px 30px -10px rgba(79, 70, 229, 0.3);
    }

    .hero-text h1 { font-size: 32px; margin-bottom: 8px; }

    /* KATALOG & FILTER */
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 24px;
    }

    .toolbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
      flex-wrap: wrap;
      gap: 12px;
    }

    .categories {
      display: flex;
      gap: 12px;
      overflow-x: auto;
      padding-bottom: 4px;
    }

    .cat-btn {
      padding: 8px 20px;
      background: white;
      border: 1px solid #e2e8f0;
      border-radius: 99px;
      cursor: pointer;
      font-size: 14px;
      font-weight: 500;
      color: var(--text-muted);
      white-space: nowrap;
      transition: all 0.2s;
    }

    .cat-btn.active, .cat-btn:hover {
      background: var(--primary);
      color: white;
      border-color: var(--primary);
    }

    /* GRID PRODUK */
    .product-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
      gap: 24px;
    }

    .product-card {
      background: var(--card-bg);
      border-radius: var(--radius);
      overflow: hidden;
      box-shadow: var(--shadow);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      display: flex;
      flex-direction: column;
      border: 1px solid #f1f5f9;
      position: relative;
    }

    .product-card:hover {
      transform: translateY(-6px);
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
    }

    .product-admin-actions {
      position: absolute;
      top: 10px;
      right: 10px;
      display: flex;
      gap: 6px;
      z-index: 10;
    }

    .btn-admin {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      border: none;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
      color: white;
      text-decoration: none;
      font-size: 12px;
    }

    .btn-edit { background: #f59e0b; }
    .btn-delete { background: #ef4444; }

    .product-img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      background-color: #f1f5f9;
    }

    .product-info {
      padding: 16px;
      display: flex;
      flex-direction: column;
      flex: 1;
    }

    .product-category {
      font-size: 12px;
      color: var(--primary);
      font-weight: 600;
      text-transform: uppercase;
      margin-bottom: 4px;
    }

    .product-title {
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 4px;
      color: var(--text-dark);
    }

    .product-stok {
      font-size: 12px;
      color: var(--text-muted);
      margin-bottom: 8px;
    }

    .product-price {
      font-size: 18px;
      font-weight: 700;
      color: #059669;
      margin-top: auto;
      margin-bottom: 12px;
    }

    .add-btn {
      width: 100%;
      padding: 10px;
      background: #f1f5f9;
      color: var(--text-dark);
      border: none;
      border-radius: 10px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      transition: all 0.2s;
    }

    .add-btn:hover {
      background: var(--primary);
      color: white;
    }

    /* SIDEBAR KERANJANG */
    .cart-overlay {
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.5);
      z-index: 200;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s ease;
    }

    .cart-overlay.active { opacity: 1; pointer-events: auto; }

    .cart-sidebar {
      position: fixed;
      top: 0;
      right: -400px;
      width: 100%;
      max-width: 380px;
      height: 100%;
      background: white;
      z-index: 201;
      box-shadow: -10px 0 25px rgba(0, 0, 0, 0.1);
      display: flex;
      flex-direction: column;
      transition: right 0.3s ease;
    }

    .cart-sidebar.active { right: 0; }

    .cart-header {
      padding: 20px;
      border-bottom: 1px solid #e2e8f0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .close-cart {
      background: none;
      border: none;
      font-size: 20px;
      cursor: pointer;
      color: var(--text-muted);
    }

    .cart-body {
      padding: 20px;
      flex: 1;
      overflow-y: auto;
    }

    .cart-item {
      display: flex;
      gap: 12px;
      margin-bottom: 16px;
      align-items: center;
    }

    .cart-item img {
      width: 50px;
      height: 50px;
      border-radius: 8px;
      object-fit: cover;
    }

    .cart-item-details { flex: 1; }
    .cart-item-title { font-size: 14px; font-weight: 600; }
    .cart-item-price { font-size: 13px; color: var(--text-muted); }

    .cart-footer {
      padding: 20px;
      border-top: 1px solid #e2e8f0;
    }

    .total-price {
      display: flex;
      justify-content: space-between;
      font-size: 18px;
      font-weight: 700;
      margin-bottom: 16px;
    }

    .checkout-btn {
      width: 100%;
      padding: 12px;
      background: var(--primary);
      color: white;
      border: none;
      border-radius: 10px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
    }

    .checkout-btn:hover { background: var(--primary-hover); }

    @media (max-width: 640px) {
      .hero-banner { flex-direction: column; text-align: center; gap: 16px; }
      .nav-container { flex-wrap: wrap; }
      .search-box { order: 3; max-width: 100%; }
    }
  </style>
</head>
<body>

  <!-- HEADER / NAVBAR -->
  <header>
    <div class="nav-container">
      <a href="index.php" class="logo">
        <i class="fa-solid fa-bag-shopping"></i> TokoKita
      </a>
      
      <div class="search-box">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" id="searchInput" placeholder="Cari produk..." onkeyup="filterProducts()" />
      </div>

      <div class="nav-actions">
        <!-- Ke Tambah Produk -->
        <a href="tambah.php" class="btn-nav btn-add">
          <i class="fa-solid fa-plus"></i>
          <span>Tambah</span>
        </a>

        <!-- Ke Halaman Admin Pesanan -->
        <a href="pesanan.php" class="btn-nav btn-orders">
          <i class="fa-solid fa-list-check"></i>
          <span>Pesanan</span>
        </a>

        <!-- Keranjang -->
        <button class="cart-btn" onclick="toggleCart()">
          <i class="fa-solid fa-cart-shopping"></i>
          <span class="cart-badge" id="cartCount">0</span>
        </button>
      </div>
    </div>
    <div class="nav-actions">

    <a href="tambah.php" class="btn-nav btn-add">
        <i class="fa-solid fa-plus"></i>
        <span>Tambah</span>
    </a>

    <a href="pesanan.php" class="btn-nav btn-orders">
        <i class="fa-solid fa-list-check"></i>
        <span>Pesanan</span>
    </a>

    <!-- Tombol Logout -->
    <a href="logout.php"
       class="btn-nav"
       style="background:#ef4444;"
       onclick="return confirm('Yakin ingin logout?')">
        <i class="fa-solid fa-right-from-bracket"></i>
        <span>Logout</span>
    </a>

    <button class="cart-btn" onclick="toggleCart()">
        <i class="fa-solid fa-cart-shopping"></i>
        <span class="cart-badge" id="cartCount">0</span>
    </button>

</div>
  </header>

  <!-- HERO BANNER -->
  <div class="hero">
    <div class="hero-banner">
      <div class="hero-text">
        <h1>Selamat Belanja! ⚡</h1>
        <p>Pilih barang favoritmu dan langsung lakukan pemesanan.</p>
      </div>
      <i class="fa-solid fa-rocket" style="font-size: 64px; opacity: 0.8;"></i>
    </div>
  </div>

  <!-- MAIN CONTENT -->
  <main class="container">
    <div class="toolbar">
      <div class="categories">
        <button class="cat-btn active" onclick="filterCategory('all', this)">Semua</button>
        <?php while ($kat = mysqli_fetch_assoc($hasil_kategori)) : ?>
          <button class="cat-btn" onclick="filterCategory('<?= $kat['nama_kategori']; ?>', this)">
            <?= $kat['nama_kategori']; ?>
          </button>
        <?php endwhile; ?>
      </div>
    </div>

    <!-- Grid Produk PHP -->
    <div class="product-grid" id="productGrid">
      <?php if (mysqli_num_rows($hasil_produk) > 0) : ?>
        <?php while ($row = mysqli_fetch_assoc($hasil_produk)) : 
            // Kumpulkan ID produk yang ada di database ke array
            $valid_ids[] = (int)$row['id_produk'];
        ?>
          <div class="product-card" 
               data-title="<?= strtolower($row['nama_produk']); ?>" 
               data-category="<?= $row['nama_kategori']; ?>">
            
            <div class="product-admin-actions">
              <a href="edit.php?id=<?= $row['id_produk']; ?>" class="btn-admin btn-edit" title="Edit Produk">
                <i class="fa-solid fa-pen"></i>
              </a>
              <a href="proses_hapus.php?id=<?= $row['id_produk']; ?>" 
                 class="btn-admin btn-delete" 
                 onclick="return confirm('Yakin ingin menghapus produk ini?');">
                <i class="fa-solid fa-trash"></i>
              </a>
            </div>

            <img src="uploads/<?= !empty($row['foto']) ? $row['foto'] : 'default.jpg'; ?>" 
                 alt="<?= $row['nama_produk']; ?>" 
                 class="product-img" 
                 onerror="this.src='https://via.placeholder.com/300x200?text=No+Image'" />

            <div class="product-info">
              <span class="product-category"><?= $row['nama_kategori'] ?? 'Umum'; ?></span>
              <h3 class="product-title"><?= $row['nama_produk']; ?></h3>
              <div class="product-stok">Sisa stok: <?= $row['stok']; ?></div>
              <div class="product-price">Rp <?= number_format($row['harga'], 0, ',', '.'); ?></div>
              
              <button class="add-btn" onclick="addToCart(
                <?= $row['id_produk']; ?>, 
                '<?= addslashes($row['nama_produk']); ?>', 
                <?= $row['harga']; ?>, 
                'uploads/<?= $row['foto']; ?>'
              )">
                <i class="fa-solid fa-plus"></i> Tambah Keranjang
              </button>
            </div>
          </div>
        <?php endwhile; ?>
      <?php else : ?>
        <p style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 40px 0;">
          Belum ada produk. Silakan tambahkan barang terlebih dahulu.
        </p>
      <?php endif; ?>
    </div>
  </main>

  <!-- SIDEBAR KERANJANG -->
  <div class="cart-overlay" id="cartOverlay" onclick="toggleCart()"></div>
  <div class="cart-sidebar" id="cartSidebar">
    <div class="cart-header">
      <h3>Keranjang Belanja</h3>
      <button class="close-cart" onclick="toggleCart()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="cart-body" id="cartItems">
      <p style="text-align: center; color: var(--text-muted); margin-top: 40px;">Keranjang masih kosong.</p>
    </div>
    <div class="cart-footer">
      <div class="total-price">
        <span>Total:</span>
        <span id="totalPrice">Rp 0</span>
      </div>
      <button class="checkout-btn" onclick="goToCheckout()">Checkout Sekarang</button>
    </div>
  </div>

  <!-- JAVASCRIPT LOGIC -->
  <script>
    let cart = JSON.parse(localStorage.getItem('my_cart')) || [];
    let currentCategory = 'all';

    // Ambil daftar ID produk valid dari PHP
    const validProductIds = <?= json_encode($valid_ids); ?>;

    // FUNGSI UNTUK MENGHAPUS SISA BARANG KERANJANG YANG SUDAH DIHAPUS DARI DB
    function syncCartWithDatabase() {
      if (cart.length > 0) {
        const updatedCart = cart.filter(item => validProductIds.includes(Number(item.id)));
        
        if (updatedCart.length !== cart.length) {
          cart = updatedCart;
          saveCart(); // Update localStorage
        }
      }
    }

    function formatRupiah(number) {
      return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(number);
    }

    function addToCart(id, title, price, image) {
      const existingItem = cart.find(item => item.id === id);

      if (existingItem) {
        existingItem.qty += 1;
      } else {
        cart.push({ id, title, price, image, qty: 1 });
      }

      saveCart();
      updateCartUI();
      toggleCart();
    }

    function saveCart() {
      localStorage.setItem('my_cart', JSON.stringify(cart));
    }

    function updateCartUI() {
      const totalCount = cart.reduce((sum, item) => sum + item.qty, 0);
      document.getElementById('cartCount').innerText = totalCount;

      const cartContainer = document.getElementById('cartItems');
      if (cart.length === 0) {
        cartContainer.innerHTML = `<p style="text-align: center; color: var(--text-muted); margin-top: 40px;">Keranjang masih kosong.</p>`;
      } else {
        cartContainer.innerHTML = '';
        cart.forEach(item => {
          cartContainer.innerHTML += `
            <div class="cart-item">
              <img src="${item.image}" alt="${item.title}" onerror="this.src='https://via.placeholder.com/60'" />
              <div class="cart-item-details">
                <div class="cart-item-title">${item.title}</div>
                <div class="cart-item-price">${item.qty} x ${formatRupiah(item.price)}</div>
              </div>
            </div>
          `;
        });
      }

      const total = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
      document.getElementById('totalPrice').innerText = formatRupiah(total);
    }

    function toggleCart() {
      document.getElementById('cartOverlay').classList.toggle('active');
      document.getElementById('cartSidebar').classList.toggle('active');
    }

    function goToCheckout() {
      if (cart.length === 0) {
        alert('Keranjang Anda masih kosong!');
        return;
      }
      window.location.href = 'pesanan.php';
    }

    function filterCategory(category, btn) {
      currentCategory = category;
      document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      filterProducts();
    }

    function filterProducts() {
      const search = document.getElementById('searchInput').value.toLowerCase();
      const cards = document.querySelectorAll('.product-card');

      cards.forEach(card => {
        const title = card.getAttribute('data-title');
        const category = card.getAttribute('data-category');

        const matchesCategory = (currentCategory === 'all' || category === currentCategory);
        const matchesSearch = title.includes(search);

        if (matchesCategory && matchesSearch) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      });
    }

    // Jalankan Sinkronisasi dulu sebelum render Keranjang
    syncCartWithDatabase();
    updateCartUI();
  </script>
</body>
</html>