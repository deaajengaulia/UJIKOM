<?php
/**
 * FILE: proses_tambah.php
 * FUNGSI: Mengolah upload foto & insert database
 */
require "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_produk = mysqli_real_escape_string($koneksi, $_POST['nama_produk']);
    $id_kategori  = intval($_POST['id_kategori']);
    $harga       = intval($_POST['harga']);
    $stok        = intval($_POST['stok']);

    // Proses File Gambar
    $foto_nama = $_FILES['foto']['name'];
    $foto_tmp  = $_FILES['foto']['tmp_name'];
    $foto_ext  = strtolower(pathinfo($foto_nama, PATHINFO_EXTENSION));
    
    // Penamaan file unik
    $nama_foto_baru = time() . '_' . rand(100, 999) . '.' . $foto_ext;
    $folder_tujuan  = "uploads/" . $nama_foto_baru;

    // Pindahkan foto ke folder uploads
    if (move_uploaded_file($foto_tmp, $folder_tujuan)) {
        $query = "INSERT INTO produk (id_kategori, nama_produk, harga, stok, foto) 
                  VALUES ($id_kategori, '$nama_produk', $harga, $stok, '$nama_foto_baru')";

        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php");
            exit();
        } else {
            echo "Gagal menambahkan data: " . mysqli_error($koneksi);
        }
    } else {
        echo "Gagal mengunggah gambar.";
    }
}
?>