<?php
/**
 * FILE: edit.php
 * FUNGSI: Form edit data produk
 */
require "koneksi.php";

$id_produk = intval($_GET['id']);

// Ambil data produk berdasarkan ID
$query_produk = "SELECT * FROM produk WHERE id_produk = $id_produk";
$hasil_produk = mysqli_query($koneksi, $query_produk);
$produk       = mysqli_fetch_assoc($hasil_produk);

if (!$produk) {
    header("Location: index.php");
    exit();
}

// Ambil semua kategori
$query_kategori = "SELECT * FROM kategori ORDER BY nama_kategori ASC";
$hasil_kategori = mysqli_query($koneksi, $query_kategori);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk - Marketplace</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f8fafc; color: #0f172a; padding: 2rem 1rem; }
        .form-card { max-width: 500px; margin: 0 auto; background: #fff; padding: 2rem; border-radius: 16px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .form-card h2 { margin-bottom: 1.5rem; color: #f59e0b; font-size: 1.5rem; }
        .form-group { margin-bottom: 1.2rem; }
        .form-group label { display: block; font-weight: 600; font-size: 0.9rem; margin-bottom: 0.4rem; }
        .form-group input, .form-group select { width: 100%; padding: 0.75rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 0.9rem; box-sizing: border-box; }
        .img-preview { width: 80px; height: 80px; object-fit: cover; border-radius: 8px; margin-top: 5px; display: block; }
        .btn-submit { background-color: #f59e0b; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; width: 100%; cursor: pointer; font-size: 1rem; }
        .btn-submit:hover { background-color: #d97706; }
        .btn-back { display: inline-block; margin-top: 1rem; color: #64748b; text-decoration: none; font-size: 0.85rem; text-align: center; width: 100%; }
    </style>
</head>
<body>

<div class="form-card">
    <h2>Edit Produk</h2>
    <form action="proses_edit.php" method="POST" enctype="multipart/form-data">
        
        <input type="hidden" name="id_produk" value="<?= $produk['id_produk']; ?>">
        <input type="hidden" name="foto_lama" value="<?= $produk['foto']; ?>">

        <div class="form-group">
            <label for="nama_produk">Nama Produk</label>
            <input type="text" id="nama_produk" name="nama_produk" value="<?= htmlspecialchars($produk['nama_produk']); ?>" required>
        </div>

        <div class="form-group">
            <label for="id_kategori">Kategori</label>
            <select id="id_kategori" name="id_kategori" required>
                <?php while ($kat = mysqli_fetch_assoc($hasil_kategori)) : ?>
                    <option value="<?= $kat['id_kategori']; ?>" <?= ($kat['id_kategori'] == $produk['id_kategori']) ? 'selected' : ''; ?>>
                        <?= $kat['nama_kategori']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="harga">Harga (Rp)</label>
            <input type="number" id="harga" name="harga" value="<?= $produk['harga']; ?>" required>
        </div>

        <div class="form-group">
            <label for="stok">Stok</label>
            <input type="number" id="stok" name="stok" value="<?= $produk['stok']; ?>" required>
        </div>

        <div class="form-group">
            <label for="foto">Foto Produk (Opsional)</label>
            <input type="file" id="foto" name="foto" accept="image/*">
            <small style="color: #64748b;">Foto Saat Ini:</small>
            <img src="uploads/<?= $produk['foto']; ?>" class="img-preview" alt="Foto Produk">
        </div>

        <button type="submit" class="btn-submit">Perbarui Produk</button>
        <a href="index.php" class="btn-back">← Batal dan Kembali</a>
    </form>
</div>

</body>
</html>