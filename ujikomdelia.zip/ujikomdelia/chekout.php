<?php
/**
 * FILE: checkout.php
 * FUNGSI: Form pemesanan untuk pembeli
 */
require "koneksi.php";

// Proses saat pembeli menekan tombol 'Konfirmasi Pesanan'
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_pembeli = $_POST['nama_pembeli'];
    $no_hp        = $_POST['no_hp'];
    $alamat       = $_POST['alamat'];
    $total_harga  = $_POST['total_harga'];
    $cart_json    = $_POST['cart_data']; // Data produk dalam format JSON

    $cart = json_decode($cart_json, true);

    if (!empty($cart)) {
        // 1. Simpan ke tabel pesanan
        $query_pesanan = "INSERT INTO pesanan (nama_pembeli, no_hp, alamat, total_harga, status) 
                          VALUES ('$nama_pembeli', '$no_hp', '$alamat', '$total_harga', 'Pending')";
        
        if (mysqli_query($koneksi, $query_pesanan)) {
            $id_pesanan_baru = mysqli_insert_id($koneksi);

            // 2. Simpan setiap item ke tabel detail_pesanan & kurangi stok
            foreach ($cart as $item) {
                $id_produk    = $item['id'];
                $jumlah       = $item['qty'];
                $harga_satuan = $item['price'];

                $query_detail = "INSERT INTO detail_pesanan (id_pesanan, id_produk, jumlah, harga_satuan) 
                                 VALUES ('$id_pesanan_baru', '$id_produk', '$jumlah', '$harga_satuan')";
                mysqli_query($koneksi, $query_detail);

                // Kurangi stok produk di database
                $query_stok = "UPDATE produk SET stok = stok - $jumlah WHERE id_produk = '$id_produk'";
                mysqli_query($koneksi, $query_stok);
            }

            echo "<script>
                alert('Pesanan berhasil dibuat! Admin akan segera memproses pesanan Anda.');
                localStorage.removeItem('checkout_cart');
                window.location.href = 'index.php';
            </script>";
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Pemesanan</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f8fafc; color: #0f172a; padding: 2rem 1rem; }
        .checkout-container { max-width: 600px; margin: 0 auto; background: #fff; padding: 2rem; border-radius: 16px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        h2 { color: #4f46e5; margin-bottom: 1.5rem; }
        .form-group { margin-bottom: 1.2rem; }
        .form-group label { display: block; font-weight: 600; font-size: 0.9rem; margin-bottom: 0.4rem; }
        .form-group input, .form-group textarea { width: 100%; padding: 0.75rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 0.9rem; box-sizing: border-box; }
        .order-summary { background: #f1f5f9; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; }
        .order-item { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.9rem; }
        .order-total { display: flex; justify-content: space-between; font-weight: 700; font-size: 1.1rem; border-top: 1px solid #cbd5e1; padding-top: 8px; margin-top: 8px; color: #059669; }
        .btn-submit { background-color: #4f46e5; color: white; border: none; padding: 0.85rem; border-radius: 8px; font-weight: 600; width: 100%; cursor: pointer; font-size: 1rem; }
        .btn-submit:hover { background-color: #4338ca; }
        .btn-back { display: block; text-align: center; margin-top: 1rem; color: #64748b; text-decoration: none; font-size: 0.85rem; }
    </style>
</head>
<body>

<div class="checkout-container">
    <h2>Form Pemesanan</h2>

    <!-- Ringkasan Produk yang dibeli -->
    <div class="order-summary">
        <h4 style="margin-bottom: 10px;">Ringkasan Pesanan:</h4>
        <div id="summaryList"></div>
        <div class="order-total">
            <span>Total Bayar:</span>
            <span id="summaryTotal">Rp 0</span>
        </div>
    </div>

    <!-- Form Data Pembeli -->
    <form action="" method="POST" id="checkoutForm">
        <input type="hidden" name="cart_data" id="cartDataInput">
        <input type="hidden" name="total_harga" id="totalHargaInput">

        <div class="form-group">
            <label for="nama_pembeli">Nama Lengkap</label>
            <input type="text" id="nama_pembeli" name="nama_pembeli" required placeholder="Contoh: Budi Santoso">
        </div>

        <div class="form-group">
            <label for="no_hp">No. WhatsApp / HP</label>
            <input type="tel" id="no_hp" name="no_hp" required placeholder="08123456789">
        </div>

        <div class="form-group">
            <label for="alamat">Alamat Lengkap Pengiriman</label>
            <textarea id="alamat" name="alamat" rows="3" required placeholder="Jl. Mawar No. 123, Kel. Suka Maju..."></textarea>
        </div>

        <button type="submit" class="btn-submit">Konfirmasi & Kirim Pesanan</button>
        <a href="index.php" class="btn-back">← Batal dan Kembali</a>
    </form>
</div>

<script>
    // Ambil data keranjang dari localStorage
    const cart = JSON.parse(localStorage.getItem('checkout_cart')) || [];

    if (cart.length === 0) {
        alert('Keranjang Anda kosong!');
        window.location.href = 'index.php';
    }

    function formatRupiah(number) {
        return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(number);
    }

    // Render Ringkasan Pesanan
    const summaryList = document.getElementById('summaryList');
    let total = 0;

    cart.forEach(item => {
        const subtotal = item.price * item.qty;
        total += subtotal;
        summaryList.innerHTML += `
            <div class="order-item">
                <span>${item.title} x ${item.qty}</span>
                <span>${formatRupiah(subtotal)}</span>
            </div>
        `;
    });

    document.getElementById('summaryTotal').innerText = formatRupiah(total);
    
    // Masukkan data ke input hidden sebelum dikirim ke server
    document.getElementById('cartDataInput').value = JSON.stringify(cart);
    document.getElementById('totalHargaInput').value = total;
</script>

</body>
</html>