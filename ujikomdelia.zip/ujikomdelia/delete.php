<?php
/**
 * FILE: delete.php
 * FUNGSI: Menghapus data produk dan berkas foto terkait
 */
require "koneksi.php";

if (isset($_GET['id'])) {
    $id_produk = intval($_GET['id']);

    // Cari nama file foto terlebih dahulu
    $query_foto = "SELECT foto FROM produk WHERE id_produk = $id_produk";
    $hasil_foto = mysqli_query($koneksi, $query_foto);
    $data_foto  = mysqli_fetch_assoc($hasil_foto);

    if ($data_foto) {
        $file_foto = "uploads/" . $data_foto['foto'];

        // Hapus fisik foto dari folder jika ditemukan
        if (file_exists($file_foto) && $data_foto['foto'] != 'default.jpg') {
            unlink($file_foto);
        }

        // Hapus record dari database
        $query_delete = "DELETE FROM produk WHERE id_produk = $id_produk";
        if (mysqli_query($koneksi, $query_delete)) {
            header("Location: index.php");
            exit();
        } else {
            echo "Gagal menghapus data dari database: " . mysqli_error($koneksi);
        }
    } else {
        echo "Data produk tidak ditemukan.";
    }
} else {
    header("Location: index.php");
    exit();
}
?>