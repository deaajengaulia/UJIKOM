<?php
require "koneksi.php";

// Pastikan ada parameter 'id' yang dikirim lewat URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // 1. Ambil nama file foto terlebih dahulu agar bisa dihapus dari folder uploads
    $query_foto = "SELECT foto FROM produk WHERE id_produk = '$id'";
    $hasil_foto = mysqli_query($koneksi, $query_foto);
    $data = mysqli_fetch_assoc($hasil_foto);

    if ($data) {
        $foto = $data['foto'];
        
        // Hapus file fisik gambar jika bukan gambar default
        if (!empty($foto) && file_exists("uploads/" . $foto)) {
            unlink("uploads/" . $foto);
        }

        // 2. Hapus data dari database
        $query_hapus = "DELETE FROM produk WHERE id_produk = '$id'";
        
        if (mysqli_query($koneksi, $query_hapus)) {
            echo "<script>
                    alert('Produk berhasil dihapus!');
                    window.location.href = 'index.php';
                  </script>";
        } else {
            // Tampilkan error query jika gagal
            echo "Gagal menghapus data: " . mysqli_error($koneksi);
        }
    } else {
        echo "<script>
                alert('Data produk tidak ditemukan!');
                window.location.href = 'index.php';
              </script>";
    }
} else {
    header("Location: index.php");
    exit();
}
?>