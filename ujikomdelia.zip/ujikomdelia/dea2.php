<?php
include 'koneksi.php';
$page = 'home';

// Query mengambil HANYA 4 produk terbaru/unggulan untuk dipajang di beranda
$query = "SELECT produk.*, kategori.nama_kategori
          FROM produk
          LEFT JOIN kategori ON produk.id_kategori = kategori.id_kategori
          ORDER BY produk.id_produk DESC 
          LIMIT 4";
$result = mysqli_query($koneksi, $query);

// Menghitung jumlah produk unggulan yang tampil
$total_unggulan = mysqli_num_rows($result);

// Menghitung total SELURUH produk yang ada di toko (untuk info badge)
$q_total = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM produk");
$res_total = mysqli_fetch_assoc($q_total);
$total_semua_produk = $res_total['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Marketplace Hub — Beranda Belanja</title>

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

  <style>
    :root{
      --bg-overlay: rgba(8,8,8,0.55);
      --card-bg: rgba(255,255,255,0.95);
      --accent: #2563eb;       /* Primary Blue */
      --accent-2: #1e40af;     /* Darker Blue */
      --muted: #4b4b4b;
      --radius: 14px;
      --max-width: 1200px;
    }

    *{box-sizing:border-box;margin:0;padding:0}
    html,body{height:100%}
    body{
      font-family: "Poppins", system-ui, -apple-system, sans-serif;
      color: #111;
      background: url('https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=1600&auto=format&fit=crop') center/cover no-repeat fixed;
      position: relative;
      overflow-x:hidden;
      line-height:1.45;
    }

    body::before{
      content:"";
      position:fixed;
      inset:0;
      background: linear-gradient(180deg, rgba(0,0,0,0.40), rgba(0,0,0,0.70));
      backdrop-filter: blur(4px) saturate(110%);
      z-index:0;
    }

    .wrap{
      position:relative;
      z-index:10;
      max-width:var(--max-width);
      margin: 36px auto;
      padding: 28px;
      display:grid;
      grid-template-columns: 1fr;
      gap:28px;
    }

    header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      background: linear-gradient(90deg, rgba(255,255,255,0.08), rgba(255,255,255,0.03));
      padding: 18px 22px;
      border-radius: 12px;
      box-shadow: 0 6px 22px rgba(9,9,9,0.35);
      border: 1px solid rgba(255,255,255,0.08);
      backdrop-filter: blur(8px);
    }
    .brand{
      display:flex;
      gap:14px;
      align-items:center;
      text-decoration:none;
      color: #fff;
    }
    .brand .logo{
      width:54px;height:54px;border-radius:10px;
      background: linear-gradient(135deg,var(--accent-2),var(--accent));
      display:flex;align-items:center;justify-content:center;
      color: #fff;font-weight:700;font-family:"Playfair Display",serif;
      box-shadow: 0 8px 20px rgba(37,99,235,0.3), inset 0 -4px 8px rgba(0,0,0,0.12);
      font-size:22px;
    }
    .brand .text{
      color:#fff;
      display:flex;flex-direction:column;
      line-height:1.2;
    }
    .brand .text .title{ font-family:"Playfair Display",serif; font-size:20px; font-weight:700; }
    .brand .text .sub{ font-size:12px; color:rgba(255,255,255,0.9); }

    nav.primary{
      display:flex;
      gap:14px;
      align-items:center;
    }
    nav.primary a{
      display:flex;
      gap:8px;
      align-items:center;
      padding:8px 14px;
      border-radius:10px;
      color: rgba(255,255,255,0.94);
      text-decoration:none;
      font-weight:600;
      font-size:14px;
      transition: transform .22s ease, background .22s ease;
    }
    nav.primary a .em{ font-size:18px; }
    nav.primary a:hover{
      transform: translateY(-3px);
      background: rgba(255,255,255,0.12);
    }
    nav.primary a.active{
      background: rgba(255,255,255,0.18);
      border: 1px solid rgba(255,255,255,0.2);
    }

    .hero{
      display:grid;
      grid-template-columns: 1fr;
      gap: 20px;
      background: linear-gradient(180deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02));
      padding: 36px;
      border-radius: 12px;
      border:1px solid rgba(255,255,255,0.06);
      box-shadow: 0 10px 30px rgba(6,6,6,0.4);
    }
    .hero-inner{
      display:flex;
      gap:28px;
      align-items:center;
      justify-content:space-between;
      flex-wrap:wrap;
    }
    .hero-left{
      flex:1 1 520px;
      min-width:260px;
    }
    .eyebrow{
      color: #60a5fa;
      font-weight:700;
      font-size:13px;
      letter-spacing:1px;
      text-transform:uppercase;
      margin-bottom:10px;
    }
    .hero h1{
      font-family:"Playfair Display",serif;
      font-size:42px;
      color:#fff;
      margin-bottom:14px;
      line-height:1.1;
    }
    .hero p.lead{
      color: rgba(255,255,255,0.92);
      max-width:780px;
      margin-bottom:20px;
      font-size:15px;
    }
    .hero .actions{ display:flex; gap:12px; flex-wrap:wrap; }
    .btn{
      display:inline-flex;
      align-items:center;
      gap:10px;
      padding:12px 20px;
      border-radius:10px;
      text-decoration:none;
      font-weight:600;
      transition: transform .18s ease;
    }
    .btn.primary{
      background: linear-gradient(90deg,var(--accent),var(--accent-2));
      color:#fff;
      box-shadow: 0 10px 30px rgba(37,99,235,0.35);
    }
    .btn.ghost{
      background: transparent;
      border: 1px solid rgba(255,255,255,0.2);
      color: #fff;
    }
    .btn:hover{ transform: translateY(-3px) }

    /* Grid Katalog Produk 4 Kolom */
    .featured{
      display:grid;
      grid-template-columns: repeat(4, 1fr);
      gap:20px;
      margin-top:16px;
    }

    .card{
      background: var(--card-bg);
      border-radius: 12px;
      overflow:hidden;
      box-shadow: 0 10px 25px rgba(0,0,0,0.25);
      transition: transform .22s ease, box-shadow .22s ease;
      display:flex;
      flex-direction:column;
      min-height: 370px;
      border: 1px solid rgba(10,10,10,0.05);
    }
    .card:hover{ transform: translateY(-8px); box-shadow: 0 18px 35px rgba(0,0,0,0.35) }
    
    /* PENTING: Perbaikan foto thumbnail */
    .card .thumb{
      height:180px;
      background-size:cover;
      background-position:center;
      background-repeat:no-repeat;
      background-color:#e2e8f0; /* Cadangan jika foto gagal dimuat */
      position: relative;
    }
    
    .card .badge-kat{
      position: absolute;
      top: 10px;
      left: 10px;
      background: rgba(0, 0, 0, 0.70);
      color: #fff;
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 600;
      backdrop-filter: blur(4px);
    }
    .card .body{
      padding:16px;
      display:flex;
      flex-direction:column;
      gap:8px;
      flex:1;
    }
    .card h3{ font-size:16px; color:#111; font-weight:700; line-height:1.3 }
    .card p{ font-size:12px; color:var(--muted); flex:1; line-height:1.4 }
    .card .stok{ font-size:11px; color:#059669; font-weight:600; }
    .card .meta{
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:10px;
      margin-top:8px;
    }
    .price{
      font-weight:700;
      color:var(--accent-2);
      font-size: 15px;
    }
    .order{
      background: var(--accent);
      color:#fff;
      padding:8px 14px;
      border-radius:8px;
      text-decoration:none;
      font-weight:600;
      font-size:12px;
      transition: background .2s ease;
    }
    .order:hover{ background: var(--accent-2); }

    /* Floating Panel Kanan */
    .emoji-panel{
      position:fixed;
      right:22px;
      top: 50%;
      transform: translateY(-50%);
      z-index: 30;
      display:flex;
      flex-direction:column;
      gap:12px;
      align-items:center;
      padding:12px;
      border-radius:18px;
      background: rgba(255,255,255,0.05);
      border:1px solid rgba(255,255,255,0.08);
      box-shadow: 0 20px 40px rgba(0,0,0,0.45);
      backdrop-filter: blur(8px);
    }
    .emoji-btn{
      width:58px;height:58px;border-radius:14px;
      display:flex;align-items:center;justify-content:center;
      font-size:24px;
      cursor:pointer;
      transition: transform .18s ease;
      background: rgba(255,255,255,0.05);
      border:1px solid rgba(255,255,255,0.08);
      color:#fff;
      position:relative;
      text-decoration: none;
    }
    .emoji-btn:hover{ transform: translateY(-5px) scale(1.05); }
    .emoji-btn .label{
      position:absolute;
      right:72px;
      top:50%;
      transform:translateY(-50%) translateX(8px);
      background: rgba(0,0,0,0.85);
      color:#fff;
      padding:6px 12px;
      border-radius:8px;
      font-weight:600;
      font-size:12px;
      white-space:nowrap;
      opacity:0;
      pointer-events:none;
      transition:all .18s ease;
    }
    .emoji-btn:hover .label{ opacity:1; transform:translateY(-50%) translateX(0px) }

    .badge{
      position:absolute;
      top:6px; left:6px;
      background: #ef4444;
      color:#fff;
      font-size:10px;
      padding:3px 7px;
      border-radius:10px;
      font-weight:700;
    }

    footer.sitefoot{
      margin-top:18px;
      text-align:center;
      color:rgba(255,255,255,0.85);
      font-size:13px;
      padding:18px 6px;
    }

    @media (max-width:1100px){
      .featured{ grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width:680px){
      .wrap{ padding:16px; margin:16px; }
      header{ padding:12px; flex-direction:column; text-align:center; }
      .featured{ grid-template-columns: 1fr; }
      .emoji-panel{ right:10px; transform: translateY(-45%); padding:6px }
      .emoji-btn{ width:48px;height:48px;font-size:20px; }
      .emoji-btn .label{ display:none }
      .hero h1{ font-size:26px }
    }
  </style>
</head>
<body>

  <!-- Floating Panel Shortcuts -->
  <div class="emoji-panel">
    <a href="index.php" class="emoji-btn" title="Beranda">
      <span class="label">Beranda</span>🏠
    </a>
    <a href="katalog.php" class="emoji-btn" title="Katalog Produk">
      <span class="label">Katalog</span>🛍️
      <span class="badge"><?= $total_semua_produk; ?></span>
    </a>
    <a href="pemesanan.php" class="emoji-btn" title="Pemesanan">
      <span class="label">Pesanan</span>🛒
    </a>
    <a href="login_admin.php" class="emoji-btn" title="Admin Login">
      <span class="label">Admin Login</span>🔐
    </a>
  </div>

  <div class="wrap">

    <!-- Header / Navbar -->
    <header role="banner">
      <a href="index.php" class="brand">
        <div class="logo">MH</div>
        <div class="text">
          <div class="title">Marketplace Hub</div>
          <div class="sub">Pusat Produk Berkualitas & Terpercaya</div>
        </div>
      </a>

      <nav class="primary" role="navigation">
        <a href="index.php" class="<?php echo ($page === 'home') ? 'active' : ''; ?>"><span>Beranda</span><span class="em">🏠</span></a>
        <a href="katalog.php"><span>Katalog</span><span class="em">🛍️</span></a>
        <a href="pemesanan.php"><span>Pesanan</span><span class="em">🛒</span></a>
        <a href="login_admin.php"><span>Admin</span><span class="em">🔐</span></a>
      </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero" role="region">
      <div class="hero-inner">
        <div class="hero-left">
          <div class="eyebrow">Pusat Belanja Online</div>
          <h1>Temukan Produk Terbaik<br><span style="font-size:20px;font-weight:600;color:rgba(255,255,255,0.85)">— Kualitas terjamin dengan harga terbaik</span></h1>
          <p class="lead">
            Marketplace Hub menyediakan beragam kebutuhan mulai dari produk gadget terkini, moda fashion modern, hingga peralatan kebutuhan sehari-hari dengan promo menarik setiap harinya.
          </p>

          <div class="actions">
            <!-- Tombol Mengarah ke katalog.php -->
            <a class="btn primary" href="katalog.php">Lihat Semua Produk (<?= $total_semua_produk; ?>)</a>
            <a class="btn ghost" href="pemesanan.php">Lacak Pesanan</a>
          </div>
        </div>

        <div style="min-width:260px;flex:0 0 320px;max-width:380px;">
          <div style="background:linear-gradient(180deg, rgba(255,255,255,0.96), rgba(255,255,255,0.92)); padding:16px; border-radius:12px; box-shadow:0 14px 30px rgba(8,8,8,0.2);">
            <div style="display:flex;gap:12px;align-items:center;">
              <img src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?q=80&w=500&auto=format&fit=crop" alt="Promo" style="width:84px;height:84px;border-radius:10px;object-fit:cover;">
              <div>
                <div style="font-weight:700;color:#111;font-size:15px">Promo Flash Sale ⚡</div>
                <div style="font-size:12px;color:#555;margin-top:4px">Diskon spesial hingga 30% untuk seluruh varian produk minggu ini!</div>
                <div style="margin-top:8px"><a href="katalog.php" class="order" style="text-decoration:none; font-size:11px; padding:6px 10px;">Beli Sekarang</a></div>
              </div>
            </div>
          </div>

          <div style="margin-top:12px; padding:12px; border-radius:10px; background:rgba(255,255,255,0.06); color:#fff; font-size:13px; text-align:center; border: 1px solid rgba(255,255,255,0.08);">
            <div style="font-weight:700">Layanan Pelanggan</div>
            <div style="opacity:0.95;margin-top:4px">Pengiriman Cepat & Respon 24/7</div>
          </div>
        </div>
      </div>

      <!-- Section Produk Unggulan Tetap (Hanya Tampil Maksimal 4 Pilihan) -->
      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:28px;">
        <h2 id="katalog" style="color:#fff; font-family:'Playfair Display', serif; font-size:26px;">Katalog Produk Unggulan</h2>
        <a href="katalog.php" style="color:#60a5fa; text-decoration:none; font-size:13px; font-weight:600;">Lihat Selengkapnya →</a>
      </div>

      <div class="featured">
        <?php if($total_unggulan > 0): ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
            <?php 
              // Menghindari foto blank/rusak dengan memberikan fallback image
              $foto_produk = !empty($row['foto']) ? $row['foto'] : 'https://via.placeholder.com/400x300?text=Gambar+Produk';
            ?>
            <article class="card">
              <div class="thumb" style="background-image:url('<?= $foto_produk; ?>');">
                <span class="badge-kat"><?= $row['nama_kategori'] ?? 'Umum'; ?></span>
              </div>
              <div class="body">
                <h3><?= $row['nama_produk']; ?></h3>
                <p><?= substr($row['deskripsi'], 0, 80) . '...'; ?></p>
                <div class="stok">Stok: <?= $row['stok']; ?> unit</div>
                <div class="meta">
                  <div class="price">Rp <?= number_format($row['harga'], 0, ',', '.'); ?></div>
                  <a class="order" href="detail_produk.php?id=<?= $row['id_produk']; ?>">Beli / Detail</a>
                </div>
              </div>
            </article>
          <?php endwhile; ?>
        <?php else: ?>
          <p style="color:#fff; grid-column: 1/-1;">Belum ada produk unggulan yang tersedia.</p>
        <?php endif; ?>
      </div>
    </section>

    <!-- Footer -->
    <footer class="sitefoot">
      📍 Marketplace Hub Indonesia — Platform Belanja Online Terpercaya • Email: support@marketplacehub.id
    </footer>

  </div>

  <script>
    document.querySelectorAll('a[href^="#"]').forEach(a=>{
      a.addEventListener('click', e=>{
        e.preventDefault();
        const id = a.getAttribute('href').slice(1);
        const el = document.getElementById(id);
        if(el) el.scrollIntoView({behavior:'smooth', block:'start'});
      })
    });
  </script>
</body>
</html>