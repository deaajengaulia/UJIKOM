<?php
/**
 * FILE: tambah.php
 * FUNGSI: Form input produk baru oleh admin
 */
require "koneksi.php";

// Ambil data kategori untuk pilihan dropdown
$query_kategori = "SELECT * FROM kategori ORDER BY nama_kategori ASC";
$hasil_kategori = mysqli_query($koneksi, $query_kategori);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk Baru - TokoKita</title>
    <!-- Google Fonts & Font Awesome Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
        body { background-color: #f8fafc; color: #0f172a; padding: 2rem 1rem; }
        
        .form-card { 
            max-width: 500px; 
            margin: 0 auto; 
            background: #fff; 
            padding: 2rem; 
            border-radius: 16px; 
            border: 1px solid #e2e8f0; 
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05); 
        }
        
        .form-card h2 { 
            margin-bottom: 1.5rem; 
            color: #4f46e5; 
            font-size: 1.5rem; 
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-group { margin-bottom: 1.2rem; }
        .form-group label { display: block; font-weight: 600; font-size: 0.9rem; margin-bottom: 0.4rem; color: #334155; }
        .form-group input, .form-group select { 
            width: 100%; 
            padding: 0.75rem 1rem; 
            border: 1px solid #cbd5e1; 
            border-radius: 8px; 
            font-size: 0.9rem; 
            outline: none;
            transition: border-color 0.2s;
        }
        .form-group input:focus, .form-group select:focus {
            border-color: #4f46e5;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }

        .btn-submit { 
            background-color: #4f46e5; 
            color: white; 
            border: none; 
            padding: 0.85rem; 
            border-radius: 8px; 
            font-weight: 600; 
            width: 100%; 
            cursor: pointer; 
            font-size: 1rem; 
            transition: background 0.2s;
            margin-top: 1rem;
        }
        .btn-submit:hover { background-color: #4338ca; }
        
        .btn-back { 
            display: block; 
            margin-top: 1rem; 
            color: #64748b; 
            text-decoration: none; 
            font-size: 0.85rem; 
            text-align: center; 
            font-weight: 500;
        }
        .btn-back:hover { color: #0f172a; }
    </style>
</head>
<body>

<div class="form-card">
    <h2><i class="fa-solid fa-box-archive"></i> Tambah Produk Baru</h2>
    
    <!-- Form menuju ke proses_tambah.php -->
    <form action="proses_tambah.php" method="POST" enctype="multipart/form-data">
        
        <div class="form-group">
            <label for="nama_produk">Nama Produk</label>
            <input type="text" id="nama_produk" name="nama_produk" required placeholder="Contoh: Sepatu Sneakers Casual">
        </div>

        <div class="form-group">
            <label for="id_kategori">Kategori</label>
            <select id="id_kategori" name="id_kategori" required>
                <option value="">-- Pilih Kategori --</option>
                <?php while ($kat = mysqli_fetch_assoc($hasil_kategori)) : ?>
                    <option value="<?= $kat['id_kategori']; ?>"><?= $kat['nama_kategori']; ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="harga">Harga (Rp)</label>
            <input type="number" id="harga" name="harga" required placeholder="150000" min="0">
        </div>

        <div class="form-group">
            <label for="stok">Stok Produk</label>
            <input type="number" id="stok" name="stok" required placeholder="10" min="0">
        </div>

        <div class="form-group">
            <label for="foto">Foto Produk</label>
            <input type="file" id="foto" name="foto" accept="image/*" required>
        </div>

        <button type="submit" class="btn-submit">
            <i class="fa-solid fa-floppy-disk"></i> Simpan Produk
        </button>
        <a href="index.php" class="btn-back">← Batal dan Kembali ke Toko</a>
    </form>
</div>

</body>
</html>