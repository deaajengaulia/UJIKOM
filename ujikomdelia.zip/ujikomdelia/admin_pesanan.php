<?php
/**
 * FILE: admin_pesanan.php
 * FUNGSI: Menampilkan dan mengelola data pesanan yang dikirim oleh pembeli
 */
session_start();
require "koneksi.php";

// Pesan Notifikasi
$pesan_sukses = "";
$pesan_error = "";

// --- 1. FITUR UBAH STATUS PESANAN ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $id_pesanan = intval($_POST['id_pesanan']);
    $status_baru = mysqli_real_escape_string($koneksi, $_POST['status']);

    $q_update = "UPDATE pesanan SET status = '$status_baru' WHERE id_pesanan = $id_pesanan";
    if (mysqli_query($koneksi, $q_update)) {
        $pesan_sukses = "Status pesanan #$id_pesanan berhasil diperbarui menjadi '$status_baru'!";
    } else {
        $pesan_error = "Gagal memperbarui status: " . mysqli_error($koneksi);
    }
}

// --- 2. FITUR HAPUS PESANAN ---
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id_pesanan = intval($_GET['id']);
    
    $q_hapus = "DELETE FROM pesanan WHERE id_pesanan = $id_pesanan";
    if (mysqli_query($koneksi, $q_hapus)) {
        $pesan_sukses = "Pesanan #$id_pesanan berhasil dihapus dari sistem!";
    } else {
        $pesan_error = "Gagal menghapus pesanan: " . mysqli_error($koneksi);
    }
}

// --- 3. AMBIL DATA PESANAN DARI DATABASE ---
// Jika tabel pesanan menyimpan id_produk, kita JOIN dengan tabel produk agar nama produk muncul
$query_pesanan = "SELECT pesanan.*, produk.nama_produk 
                  FROM pesanan 
                  LEFT JOIN produk ON pesanan.id_produk = produk.id_produk 
                  ORDER BY pesanan.id_pesanan DESC";
$result_pesanan = mysqli_query($koneksi, $query_pesanan);

// Jika query JOIN gagal (karena belum ada kolom id_produk di tabel pesanan), fallback ke query biasa
if (!$result_pesanan) {
    $query_pesanan = "SELECT * FROM pesanan ORDER BY id_pesanan DESC";
    $result_pesanan = mysqli_query($koneksi, $query_pesanan);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pesanan Masuk - Admin TokoKita</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
        body { background-color: #f8fafc; color: #0f172a; padding-bottom: 3rem; }

        /* NAVBAR ADMIN */
        .navbar { background: #1e293b; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; color: #fff; position: sticky; top: 0; z-index: 100; }
        .logo { font-size: 1.3rem; font-weight: 700; color: #38bdf8; text-decoration: none; display: flex; align-items: center; gap: 8px; }
        .badge-admin { background: #0284c7; color: #fff; padding: 3px 8px; border-radius: 6px; font-size: 0.75rem; text-transform: uppercase; font-weight: 700; }
        .btn-kembali { background: #334155; color: #f8fafc; text-decoration: none; padding: 8px 16px; border-radius: 8px; font-size: 0.85rem; font-weight: 600; transition: background 0.2s; }
        .btn-kembali:hover { background: #475569; }

        /* KONTEN UTAMA */
        .container { max-width: 1200px; margin: 2rem auto; padding: 0 1rem; }
        .header-section { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
        .header-section h2 { font-size: 1.5rem; color: #0f172a; display: flex; align-items: center; gap: 10px; }

        /* ALERT NOTIFIKASI */
        .alert { padding: 0.85rem 1rem; border-radius: 8px; margin-bottom: 1.5rem; font-size: 0.9rem; font-weight: 500; display: flex; align-items: center; gap: 8px; }
        .alert-success { background: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }

        /* TABEL PESANAN */
        .table-card { background: #fff; border-radius: 12px; border: 1px solid #e2e8f0; overflow-x: auto; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.875rem; min-width: 900px; }
        th { background: #f8fafc; padding: 14px 16px; font-weight: 600; color: #475569; border-bottom: 1px solid #e2e8f0; }
        td { padding: 14px 16px; border-bottom: 1px solid #e2e8f0; vertical-align: middle; }
        tr:hover { background: #f8fafc; }

        /* BADGE STATUS */
        .badge { display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; }
        .badge-Pending { background: #fef3c7; color: #b45309; }
        .badge-Diproses { background: #dbeafe; color: #1d4ed8; }
        .badge-Selesai { background: #d1fae5; color: #047857; }
        .badge-Dibatalkan { background: #fee2e2; color: #b91c1c; }

        /* FORM CHANGE STATUS */
        .form-status { display: flex; align-items: center; gap: 6px; margin-top: 6px; }
        .select-status { padding: 5px 8px; border-radius: 6px; border: 1px solid #cbd5e1; font-size: 0.8rem; background: #fff; color: #334155; }
        .btn-update { background: #4f46e5; color: #fff; border: none; padding: 5px 10px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; cursor: pointer; }
        .btn-update:hover { background: #4338ca; }

        /* TOMBOL WA & DELETE */
        .btn-wa { display: inline-flex; align-items: center; gap: 4px; background: #25d366; color: #fff; padding: 4px 10px; border-radius: 6px; text-decoration: none; font-size: 0.75rem; font-weight: 600; margin-top: 4px; }
        .btn-wa:hover { background: #1da851; }
        .btn-delete { color: #ef4444; text-decoration: none; font-weight: 600; font-size: 0.85rem; display: inline-flex; align-items: center; gap: 4px; }
        .btn-delete:hover { color: #dc2626; }
    </style>
</head>
<body>

    <!-- NAVBAR ADMIN -->
    <nav class="navbar">
        <a href="index.php" class="logo">
            <i class="fa-solid fa-user-shield"></i> Dashboard Admin
            <span class="badge-admin">Admin</span>
        </a>
        <a href="index.php" class="btn-kembali"><i class="fa-solid fa-store"></i> Lihat Toko</a>
    </nav>

    <div class="container">
        <div class="header-section">
            <h2><i class="fa-solid fa-inbox" style="color: #0284c7;"></i> Pesanan Masuk dari Pembeli</h2>
        </div>

        <!-- NOTIFIKASI -->
        <?php if (!empty($pesan_sukses)) : ?>
            <div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> <?= $pesan_sukses; ?></div>
        <?php endif; ?>

        <?php if (!empty($pesan_error)) : ?>
            <div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?= $pesan_error; ?></div>
        <?php endif; ?>

        <!-- TABEL DATA PESANAN -->
        <div class="table-card">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Data Pembeli</th>
                        <th>Alamat Pengiriman</th>
                        <th>Produk / Detail</th>
                        <th>Total Bayar</th>
                        <th>Status Pesanan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result_pesanan && mysqli_num_rows($result_pesanan) > 0) : ?>
                        <?php while ($ps = mysqli_fetch_assoc($result_pesanan)) : ?>
                            <tr>
                                <td><b>#<?= $ps['id_pesanan']; ?></b></td>
                                
                                <!-- Data Pembeli & Kontak WA -->
                                <td>
                                    <strong><?= htmlspecialchars($ps['nama_pembeli']); ?></strong><br>
                                    <small style="color: #64748b;"><i class="fa-solid fa-phone"></i> <?= htmlspecialchars($ps['no_hp']); ?></small><br>
                                    <!-- Tombol WhatsApp Otomatis -->
                                    <?php 
                                        $no_wa = preg_replace('/^0/', '62', $ps['no_hp']); 
                                        $teks_wa = urlencode("Halo " . $ps['nama_pembeli'] . ", kami dari Admin Toko. Mengenai pesanan #" . $ps['id_pesanan'] . "...");
                                    ?>
                                    <a href="https://wa.me/<?= $no_wa; ?>?text=<?= $teks_wa; ?>" target="_blank" class="btn-wa">
                                        <i class="fa-brands fa-whatsapp"></i> Chat Pembeli
                                    </a>
                                </td>

                                <!-- Alamat -->
                                <td style="max-width: 220px;">
                                    <small style="color: #334155;"><i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($ps['alamat']); ?></small>
                                </td>

                                <!-- Produk (Jika ada relasi ke produk/jumlah) -->
                                <td>
                                    <?php if (isset($ps['nama_produk']) && $ps['nama_produk']) : ?>
                                        <b><?= htmlspecialchars($ps['nama_produk']); ?></b>
                                        <?php if (isset($ps['jumlah'])) : ?>
                                            <br><small style="color: #64748b;">Jumlah: <?= $ps['jumlah']; ?> item</small>
                                        <?php endif; ?>
                                    <?php else : ?>
                                        <span style="color: #64748b; font-style: italic;">Item Pesanan</span>
                                    <?php endif; ?>
                                </td>

                                <!-- Total Harga -->
                                <td><b style="color: #059669;">Rp <?= number_format($ps['total_harga'], 0, ',', '.'); ?></b></td>

                                <!-- Status & Form Ubah Status -->
                                <td>
                                    <span class="badge badge-<?= $ps['status']; ?>"><?= $ps['status']; ?></span>

                                    <form action="" method="POST" class="form-status">
                                        <input type="hidden" name="id_pesanan" value="<?= $ps['id_pesanan']; ?>">
                                        <select name="status" class="select-status">
                                            <option value="Pending" <?= $ps['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="Diproses" <?= $ps['status'] == 'Diproses' ? 'selected' : ''; ?>>Diproses</option>
                                            <option value="Selesai" <?= $ps['status'] == 'Selesai' ? 'selected' : ''; ?>>Selesai</option>
                                            <option value="Dibatalkan" <?= $ps['status'] == 'Dibatalkan' ? 'selected' : ''; ?>>Dibatalkan</option>
                                        </select>
                                        <button type="submit" name="update_status" class="btn-update">Simpan</button>
                                    </form>
                                </td>

                                <!-- Aksi Hapus -->
                                <td>
                                    <a href="admin_pesanan.php?action=delete&id=<?= $ps['id_pesanan']; ?>" 
                                       onclick="return confirm('Apakah Anda yakin ingin menghapus pesanan #<?= $ps['id_pesanan']; ?>?');" 
                                       class="btn-delete">
                                        <i class="fa-solid fa-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="7" style="text-align: center; color: #64748b; padding: 3rem;">
                                <i class="fa-solid fa-inbox" style="font-size: 2rem; margin-bottom: 0.5rem; opacity: 0.5;"></i><br>
                                Belum ada pesanan masuk dari pembeli.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>