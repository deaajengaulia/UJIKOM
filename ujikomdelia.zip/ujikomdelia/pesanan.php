<?php
/**
 * FILE: pesanan.php
 * FUNGSI: Formulir Pemesanan Barang untuk Pembeli
 */
session_start();
require "koneksi.php";

$pesan_sukses = "";
$pesan_error = "";

// --- PROSES FORM PEMESANAN ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buat_pesanan'])) {
    $nama_pembeli = mysqli_real_escape_string($koneksi, trim($_POST['nama_pembeli']));
    $no_hp        = mysqli_real_escape_string($koneksi, trim($_POST['no_hp']));
    $alamat       = mysqli_real_escape_string($koneksi, trim($_POST['alamat']));
    $id_produk    = intval($_POST['id_produk']);
    $jumlah       = intval($_POST['jumlah']);

    // Validasi dasar
    if (empty($nama_pembeli) || empty($no_hp) || empty($alamat) || $id_produk <= 0 || $jumlah <= 0) {
        $pesan_error = "Semua field formulir wajib diisi dengan benar!";
    } else {
        // Cek stok & harga produk di database
        $q_produk = mysqli_query($koneksi, "SELECT harga, stok, nama_produk FROM produk WHERE id_produk = $id_produk");
        $data_produk = mysqli_fetch_assoc($q_produk);

        if (!$data_produk) {
            $pesan_error = "Produk yang dipilih tidak ditemukan.";
        } elseif ($data_produk['stok'] < $jumlah) {
            $pesan_error = "Stok produk '" . htmlspecialchars($data_produk['nama_produk']) . "' tidak mencukupi! (Sisa stok: " . $data_produk['stok'] . ")";
        } else {
            // Hitung total harga
            $total_harga = $data_produk['harga'] * $jumlah;
            $status      = "Pending";

            // 1. Simpan data pesanan
            $q_pesanan = "INSERT INTO pesanan (nama_pembeli, no_hp, alamat, total_harga, status) 
                          VALUES ('$nama_pembeli', '$no_hp', '$alamat', '$total_harga', '$status')";

            if (mysqli_query($koneksi, $q_pesanan)) {
                // 2. Kurangi stok produk
                $stok_baru = $data_produk['stok'] - $jumlah;
                mysqli_query($koneksi, "UPDATE produk SET stok = $stok_baru WHERE id_produk = $id_produk");

                $pesan_sukses = "Terima kasih! Pesanan Anda berhasil dibuat dengan total pembayaran Rp " . number_format($total_harga, 0, ',', '.') . ". Admin akan segera menghubungi Anda.";
            } else {
                $pesan_error = "Gagal menyimpan pesanan: " . mysqli_error($koneksi);
            }
        }
    }
}

// Ambil daftar produk yang stoknya masih ada (> 0)
$q_daftar_produk = mysqli_query($koneksi, "SELECT * FROM produk WHERE stok > 0 ORDER BY nama_produk ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pemesanan - TokoKita</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
        body { background-color: #f8fafc; color: #0f172a; padding-bottom: 3rem; }

        /* NAVBAR */
        .navbar { background: #fff; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; position: sticky; top: 0; z-index: 100; }
        .logo { font-size: 1.4rem; font-weight: 700; color: #4f46e5; text-decoration: none; display: flex; align-items: center; gap: 8px; }
        .btn-kembali { background: #f1f5f9; color: #475569; text-decoration: none; padding: 8px 16px; border-radius: 8px; font-size: 0.85rem; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; }
        .btn-kembali:hover { background: #e2e8f0; }

        /* KONTEN UTAMA */
        .container { max-width: 600px; margin: 2.5rem auto; padding: 0 1rem; }
        .card-form { background: #fff; border-radius: 12px; border: 1px solid #e2e8f0; padding: 2rem; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); }
        .card-form h2 { font-size: 1.5rem; margin-bottom: 0.5rem; color: #0f172a; text-align: center; }
        .card-form p.subtitle { font-size: 0.9rem; color: #64748b; text-align: center; margin-bottom: 1.5rem; }

        /* ALERT NOTIFIKASI */
        .alert { padding: 0.85rem 1rem; border-radius: 8px; margin-bottom: 1.5rem; font-size: 0.9rem; font-weight: 500; display: flex; align-items: center; gap: 8px; }
        .alert-success { background: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }

        /* INPUT FORM */
        .form-group { margin-bottom: 1.25rem; }
        .form-group label { display: block; font-size: 0.875rem; font-weight: 600; color: #334155; margin-bottom: 0.4rem; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 0.75rem 1rem; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.9rem; background: #fff; color: #0f172a; outline: none; transition: border-color 0.2s; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: #4f46e5; box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
        .form-group textarea { resize: vertical; min-height: 90px; }

        /* BOX TOTAL HARGA */
        .total-box { background: #f1f5f9; padding: 1rem; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; margin-top: 1.5rem; border: 1px dashed #cbd5e1; }
        .total-box span { font-size: 0.9rem; font-weight: 600; color: #475569; }
        .total-box strong { font-size: 1.3rem; color: #059669; }

        /* TOMBOL SUBMIT */
        .btn-submit { width: 100%; background: #4f46e5; color: #fff; border: none; padding: 0.85rem; border-radius: 8px; font-size: 0.95rem; font-weight: 600; cursor: pointer; margin-top: 1.5rem; transition: background 0.2s; display: flex; justify-content: center; align-items: center; gap: 8px; }
        .btn-submit:hover { background: #4338ca; }
    </style>
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar">
        <a href="index.php" class="logo"><i class="fa-solid fa-bag-shopping"></i> TokoKita</a>
        <a href="index.php" class="btn-kembali"><i class="fa-solid fa-arrow-left"></i> Kembali ke Toko</a>
    </nav>

    <div class="container">
        <div class="card-form">
            <h2><i class="fa-solid fa-cart-flatbed" style="color: #4f46e5;"></i> Formulir Pesanan</h2>
            <p class="subtitle">Isi data diri Anda dengan benar untuk melakukan pemesanan barang</p>

            <!-- ALERT NOTIFIKASI -->
            <?php if (!empty($pesan_sukses)) : ?>
                <div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> <?= $pesan_sukses; ?></div>
            <?php endif; ?>

            <?php if (!empty($pesan_error)) : ?>
                <div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?= $pesan_error; ?></div>
            <?php endif; ?>

            <form action="" method="POST">
                <!-- Data Pembeli -->
                <div class="form-group">
                    <label for="nama_pembeli"><i class="fa-solid fa-user"></i> Nama Lengkap</label>
                    <input type="text" id="nama_pembeli" name="nama_pembeli" placeholder="Contoh: Budi Santoso" required>
                </div>

                <div class="form-group">
                    <label for="no_hp"><i class="fa-solid fa-phone"></i> Nomor WhatsApp / HP</label>
                    <input type="tel" id="no_hp" name="no_hp" placeholder="Contoh: 08123456789" required>
                </div>

                <div class="form-group">
                    <label for="alamat"><i class="fa-solid fa-location-dot"></i> Alamat Lengkap Pengiriman</label>
                    <textarea id="alamat" name="alamat" placeholder="Jalan, No. Rumah, RT/RW, Kecamatan, Kota" required></textarea>
                </div>

                <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 1.5rem 0;">

                <!-- Pilih Produk -->
                <div class="form-group">
                    <label for="id_produk"><i class="fa-solid fa-box"></i> Pilih Produk</label>
                    <select id="id_produk" name="id_produk" required onchange="hitungTotal()">
                        <option value="" data-harga="0" data-stok="0">-- Pilih Produk --</option>
                        <?php if ($q_daftar_produk && mysqli_num_rows($q_daftar_produk) > 0) : ?>
                            <?php while ($p = mysqli_fetch_assoc($q_daftar_produk)) : ?>
                                <option value="<?= $p['id_produk']; ?>" data-harga="<?= $p['harga']; ?>" data-stok="<?= $p['stok']; ?>">
                                    <?= htmlspecialchars($p['nama_produk']); ?> - Rp <?= number_format($p['harga'], 0, ',', '.'); ?> (Stok: <?= $p['stok']; ?>)
                                </option>
                            <?php endwhile; ?>
                        <?php else : ?>
                            <option value="" disabled>Stok produk sedang kosong</option>
                        <?php endif; ?>
                    </select>
                </div>

                <!-- Jumlah Pesanan -->
                <div class="form-group">
                    <label for="jumlah"><i class="fa-solid fa-hashtag"></i> Jumlah Pembelian</label>
                    <input type="number" id="jumlah" name="jumlah" min="1" value="1" required oninput="hitungTotal()">
                </div>

                <!-- Total Estimasi -->
                <div class="total-box">
                    <span>Total Pembayaran:</span>
                    <strong id="tampilan_total">Rp 0</strong>
                </div>

                <button type="submit" name="buat_pesanan" class="btn-submit">
                    <i class="fa-solid fa-paper-plane"></i> Kirim Pesanan Sekarang
                </button>
            </form>
        </div>
    </div>

    <!-- JAVASCRIPT KALKULASI OTOMATIS -->
    <script>
        function hitungTotal() {
            const selectProduk = document.getElementById('id_produk');
            const inputJumlah = document.getElementById('jumlah');
            const tampilanTotal = document.getElementById('tampilan_total');

            const optionTerpilih = selectProduk.options[selectProduk.selectedIndex];
            const harga = parseFloat(optionTerpilih.getAttribute('data-harga')) || 0;
            const jumlah = parseInt(inputJumlah.value) || 0;

            const total = harga * jumlah;

            // Format ke Rupiah
            tampilanTotal.innerText = 'Rp ' + total.toLocaleString('id-ID');
        }
    </script>
</body>
</html>